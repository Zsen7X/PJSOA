package com.soa.soaProject.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.data.jpa.repository.Query;
import com.soa.soaProject.entity.Booking;
import com.soa.soaProject.entity.User;


@Repository
public interface BookingRepository extends JpaRepository<Booking, Integer> {
	//@Query("SELECT b.id,b.name,b.date,b.time,b.userId,u.username, FROM times NATURAL JOIN Booking as b INNER JOIN user as u ON b.user_id = u.id")	
	//@Query("SELECT b.id,b.name,b.date,b.time,b.userId,u.username FROM Booking b JOIN User u ON b.userId = u.id")
	List<Booking> findAll();

	/*@Query("SELECT b.id,b.name,b.date,b.time,b.userId,u.username FROM Booking as b")
	List<Booking> findUsernamesOfBookings();*/
	Booking findByName(String name);
}
