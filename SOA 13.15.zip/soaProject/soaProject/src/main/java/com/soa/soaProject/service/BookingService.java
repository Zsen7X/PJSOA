package com.soa.soaProject.service;
import com.soa.soaProject.dto.BookingDTO;
import com.soa.soaProject.entity.Booking;
import java.util.List;

import org.springframework.stereotype.Service;


@Service
public interface BookingService {
	List<Booking> getAllBooking();
	Booking findByName(String name);

	
}
