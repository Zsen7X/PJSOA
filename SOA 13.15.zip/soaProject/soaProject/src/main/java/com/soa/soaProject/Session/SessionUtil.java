package com.soa.soaProject.Session;

import org.hibernate.Session;
import org.hibernate.SessionFactory;


public class SessionUtil {
	private static SessionUtil instance = new SessionUtil();
	private SessionFactory sessionFactory;
	
	public static SessionUtil getInstance() {
		return instance;
	}
	
	public static Session getSession() {
		Session session = getInstance().sessionFactory.openSession();

		return session;
	}
}
