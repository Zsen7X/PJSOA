package com.soa.soaProject.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.soa.soaProject.dto.UserDTO;
import com.soa.soaProject.entity.User;
import com.soa.soaProject.repository.UserRepository;



@Service
public class UserImpl implements UserService{

	@Autowired
	PasswordEncoder passwordEncoder;
	
	private UserRepository userRepository;
	
	public UserImpl(UserRepository userRepository) {

		this.userRepository = userRepository;
	}
	
	@Override
	public User findByUsername(String username) {
		return userRepository.findByUsername(username);
	}

	@Override
	public User save(UserDTO userDTO) {
		User user = new User(userDTO.getName(),passwordEncoder.encode(userDTO.getPassword()),userDTO.getPassword());
		return userRepository.save(user);
	}
}
