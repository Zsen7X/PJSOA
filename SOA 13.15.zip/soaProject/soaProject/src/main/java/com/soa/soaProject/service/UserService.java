package com.soa.soaProject.service;


import org.springframework.stereotype.Service;

import com.soa.soaProject.dto.UserDTO;
import com.soa.soaProject.entity.User;

@Service
public interface UserService {
	User findByUsername(String username);
	User save(UserDTO userDTO);
}

