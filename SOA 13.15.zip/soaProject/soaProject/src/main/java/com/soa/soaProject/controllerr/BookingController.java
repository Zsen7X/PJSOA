package com.soa.soaProject.controllerr;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.soa.soaProject.entity.*;
import com.soa.soaProject.repository.BookingRepository;
import com.soa.soaProject.repository.UserRepository;
import com.soa.soaProject.service.UserDetailsServiceImpl;

import java.security.Principal;
import java.sql.Time;
import java.util.List;

@Controller
public class BookingController {
	
	

	@Autowired
	private BookingRepository bookingRepository;
	@Autowired
	private UserRepository userRepository;

	@Autowired
	private UserDetailsServiceImpl userDetailsService;

	@GetMapping("/index")
	public String index(Model model,Principal principal) {
		UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
		model.addAttribute("userdetail", userDetails);
		return "index";
	}
	
	
	@GetMapping("/bookingshow")
	public String showBookings(Model model, Principal principal) {
		// List<Booking> booking = bookingRepository.findUsernamesOfBookings();
		// System.out.println(booking);
		List<Booking> booking = bookingRepository.findAll();
		UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
		model.addAttribute("userdetail", userDetails);
		// List<User> user = userRepository.findAll();
		model.addAttribute("bookings", booking);
		// model.addAttribute("users", user);
		return "booking-list"; // ชื่อ template HTML
	}

	@PostMapping("/booking")
    public String BookingSave(@ModelAttribute("booking") Booking booking) {
		//System.out.println(bookingdto.getTime());
//        if (bookser != null) {
        	System.out.println("1");
        	bookingRepository.save(booking);
            return "redirect:/home";
	}
}
	
