package com.soa.soaProject;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoaProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
