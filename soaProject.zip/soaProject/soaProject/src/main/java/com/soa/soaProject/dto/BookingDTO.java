package com.soa.soaProject.dto;

import java.sql.Date;
import java.sql.Time;

public class BookingDTO {
	
	private String name;
	private int num;
	private Date date;
	private Time time;
	
	public BookingDTO() {
		
	}
	
	public BookingDTO(String name, int num, Date date, Time time) {
		this.name = name;
		this.num = num;
		this.date = date;
		this.time = time;
	}
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getNum() {
		return num;
	}
	public void setNum(int num) {
		this.num = num;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public Time  getTime() {
		return time;
	}
	public void setTime(Time time) {
		this.time = time;
	}
	

}
