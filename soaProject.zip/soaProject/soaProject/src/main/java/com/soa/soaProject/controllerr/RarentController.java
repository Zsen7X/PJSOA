package com.soa.soaProject.controllerr;

import java.security.Principal;
import java.util.Collections;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.soa.soaProject.Session.SessionUtil;
import com.soa.soaProject.dto.UserDTO;

import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import com.soa.soaProject.entity.User;
import com.soa.soaProject.repository.UserRepository;
import com.soa.soaProject.service.UserDetailsServiceImpl;
import com.soa.soaProject.service.UserService;

@Controller
public class RarentController {

	@Autowired
	private UserDetailsServiceImpl userDetailsService;
	@Autowired
	private UserService userService;
	
//    public RarentController(UserService userServices) {
//
//		this.userService = userService;
//
//	}

	@Autowired
    private UserRepository userRepository;

    @GetMapping("/home")
    public String index(Model model,Principal principal) {
    	UserDetails userDetails = userDetailsService.loadUserByUsername(principal.getName());
    	model.addAttribute("userdetail",userDetails);
        return "home";
    }

    @GetMapping("/login")
	public String Login(Model model, UserDTO userDTO) {
		model.addAttribute("user",userDTO);
		return "loginPage";
	}

    @Autowired
    private PasswordEncoder passwordEncoder;

    @PostMapping("/login")
    public String login(Model model,UserDTO userDTO){
    	model.addAttribute("user",userDTO);
    	return "login";
    }


    @GetMapping("/register")
	public String Register(Model model, UserDTO userDTO) {
		model.addAttribute("user",userDTO);
		return "registrationPage";
	}

    @PostMapping("/register")
    public String register(@ModelAttribute("user") User user,Model model) {
        String encodedPassword = BCrypt.hashpw(user.getPassword(), BCrypt.gensalt(12));
        user.setPassword(encodedPassword);
        User userDao = userService.findByUsername(user.getUsername());
        if(userDao != null) {
        	model.addAttribute("userexist",userDao);
        	return "redirect:/register";
        	
        }
        userRepository.save(user);
        System.out.println(user.getName());
        return "redirect:/login";
    }

}
